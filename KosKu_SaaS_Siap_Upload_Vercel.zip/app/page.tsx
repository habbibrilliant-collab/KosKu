import React from 'react';
import Link from 'next/link';
import { CheckCircle2, ShieldCheck, FileText, BellRing, Sparkles, ArrowRight, Smartphone, LayoutDashboard } from 'lucide-react';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary font-extrabold text-primary-foreground">
              K
            </div>
            <span className="text-lg font-extrabold tracking-tight">KosKu</span>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <Link
              href="/owner/dashboard"
              className="rounded-lg border border-border bg-secondary px-3 py-2 text-xs sm:text-sm font-semibold text-secondary-foreground"
            >
              Demo Pemilik Kos
            </Link>
            <Link
              href="/tenant/dashboard"
              className="rounded-lg border border-border bg-secondary px-3 py-2 text-xs sm:text-sm font-semibold text-secondary-foreground"
            >
              Demo Anak Kos
            </Link>
            <Link
              href="/admin"
              className="rounded-xl bg-primary px-3.5 py-2 text-xs sm:text-sm font-bold text-primary-foreground shadow-sm"
            >
              Panel Super Admin
            </Link>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-5xl px-4 pt-14 pb-16 text-center sm:px-6">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/15 px-3.5 py-1 text-xs font-bold text-primary">
          <Sparkles className="h-3.5 w-3.5" /> SaaS Manajemen Kos #1 di Indonesia
        </span>
        <h1 className="mt-5 text-3xl font-extrabold tracking-tight sm:text-5xl">
          Kelola Kamar, Tagihan Bulanan, & Invoice PDF Kos Secara Otomatis
        </h1>
        <p className="mx-auto mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
          Satu pemilik kos = satu akun organisasi yang terpisah aman. Penghuni bisa membayar 1, 3, 6, 8, atau 12 bulan dan langsung menerima Invoice PDF resmi ber-QR Code di email.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link
            href="/owner/dashboard"
            className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3.5 text-sm font-bold text-primary-foreground shadow-md"
          >
            <LayoutDashboard className="h-4 w-4" />
            <span>Buka Dasbor Pemilik Kos</span>
            <ArrowRight className="h-4 w-4" />
          </Link>
          <Link
            href="/tenant/dashboard"
            className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-6 py-3.5 text-sm font-semibold hover:bg-muted"
          >
            <span>Lihat Halaman Bayar Penghuni</span>
          </Link>
        </div>
      </section>

      <section id="harga" className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <div className="rounded-2xl border-2 border-primary bg-card p-6 shadow-md">
            <span className="rounded-full bg-primary/15 px-3 py-1 text-xs font-bold text-primary">
              PAKET DASAR (15 KAMAR)
            </span>
            <h3 className="mt-4 text-xl font-extrabold">Paket Dasar Pemilik Kos</h3>
            <p className="mt-2 text-3xl font-extrabold text-primary">
              Rp229.000
              <span className="text-xs font-normal text-muted-foreground"> / 12 bulan pertama</span>
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              Perpanjangan tahun berikutnya Rp99.000/tahun
            </p>
            <ul className="mt-5 space-y-2 text-sm">
              {[
                'Kuota hingga 15 kamar kos aktif',
                'Tagihan otomatis & pengingat H-7, H-3, Hari H',
                'Pembayaran 1, 3, 6, 8, atau 12 bulan',
                'Invoice PDF otomatis + kode QR verifikasi publik',
                'Arsip KTP terenkripsi sesuai UU PDP',
              ].map((item) => (
                <li key={item} className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm flex flex-col justify-between">
            <div>
              <span className="rounded-full bg-secondary px-3 py-1 text-xs font-bold text-secondary-foreground">
                ADD-ON KELIPATAN 15 KAMAR
              </span>
              <h3 className="mt-4 text-xl font-extrabold">Tambah +15 Kamar</h3>
              <p className="mt-2 text-3xl font-extrabold">
                Rp49.000 <span className="text-xs font-normal text-muted-foreground">/ bulan</span>
              </p>
              <p className="mt-1 text-xs font-semibold text-primary">Atau Rp490.000 / tahun</p>
              <p className="mt-4 text-sm text-muted-foreground">
                Berlaku untuk kamar ke-16 s/d 30, 31 s/d 45, dst. Dilengkapi masa tenggang 7 hari tanpa pernah menghapus data kamar Anda.
              </p>
            </div>
            <Link
              href="/owner/dashboard"
              className="mt-6 inline-flex w-full items-center justify-center rounded-xl bg-secondary py-3 text-sm font-bold text-secondary-foreground"
            >
              Coba Sekarang
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
